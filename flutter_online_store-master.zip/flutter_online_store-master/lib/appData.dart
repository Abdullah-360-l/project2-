class AppData{

  static const url='http://192.168.1.50/shop_practice/';

}