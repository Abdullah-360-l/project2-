package com.example.flutter_shop_practice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
