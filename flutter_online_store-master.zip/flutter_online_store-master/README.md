# flutter_shop_practice

Its back online shop store with flutter and api with php .
its good for practice.

![4](https://user-images.githubusercontent.com/78899995/166659337-f59dbd3f-fba5-477d-8079-9c02599bf645.jpg)

